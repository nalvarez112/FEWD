// SET UP VARIABLES 
// ------------------------------------------


var rupaul = document.querySelector(".rupaul");

// start screen
var startScreen = document.querySelector(".start-screen");


// question screen
var questionScreen = document.querySelector(".question-screen");
var gameShow = document.querySelector(".game-show");
var questionArea = document.querySelector(".question-area");
var questionText = document.querySelector(".question");
var seasonScreen = document.querySelector(".season-screen");
var choices = document.querySelector('.choices');
var qOptions = document.querySelectorAll(".choice")


// final creen
var finalScreen = document.querySelector(".final-screen");

// set up
var currentSeason = null;
var currentQuestion = null;


// START BUTTON FUNCTION
// ------------------------------------------------------
var startButton = document.querySelector(".start-button");
startButton.addEventListener('click', clickedStartButton);

// MOVE TO CHOOSE YOUR SEASON SCREEN
// ------------------------------------------------------

function clickedStartButton (e){
	showScreen('seasonScreen');
}

// PICK THE SEASON
// ------------------------------------------------------
var mainWrapper = document.querySelector("#main-wrapper")
var thumbnails = document.querySelectorAll(".thumbnails")
for (var i = 0; i < thumbnails.length; i++) {
    thumbnails[i].addEventListener('click', pickSeason);
}

function pickSeason (e) {
	var target = e.target;
	if (target.tagName != 'LI'){
		target = target.closest("li");  
	}
	console.log('season', target.dataset.season);
	currentSeason = parseInt(target.dataset.season);
	startSeason();
}

function startSeason (season) {
	console.log('startSeason', season);
	showScreen('questionScreen');
	currentQuestion = 1;
	createQuestion(seasons[season]);
}

function createQuestion (toAnswer){
	questionText.textContent = seasons[currentSeason].questions[currentQuestion].question;
	choices.innerHTML = "";
	var currentChoices = seasons[currentSeason].questions[currentQuestion].choices;

	for (i = 0; i < currentChoices.length; i++) {
		// create
		var img = document.createElement('img');
		var p = document.createElement('p');
		var li = document.createElement('li');
		
		// Att content and attribute
		img.src = currentChoices[i].image;
		p.textContent = currentChoices[i].choice;
		li.className = ".choice";
		li.dataset.choice = i;

		// append
		li.appendChild(img);
		li.appendChild(p);
		choices.appendChild(li);
		console.log('createQuestion', currentQuestion);

	}

	console.log(qOptions);
	for (var i = 0; i < qOptions.length; i++) {
	    qOptions[i].addEventListener('click', pickChoice);
	}


}

function pickChoice (e){
	var target = e.target;

	if (target.tagName != 'LI') {
		target = target.closest('li');
	}
	console.log('choice', target.dataset.choice);
	var choice = target.dataset.choice;

	if (choice == seasons[currentSeason].questions[currentQuestion].answer) {
		alert('you win');
	} else {
		alert('you loser');
	}
}



// SWITCH SCREENS
function showScreen(screen) {
	startScreen.classList.add('hide');
	seasonScreen.classList.add('hide');
	questionScreen.classList.add('hide');

	if (screen == 'startScreen') {
		startScreen.classList.remove('hide');
	} else if (screen == 'seasonScreen') {
		seasonScreen.classList.remove('hide');
	} else if (screen == 'questionScreen'){
		questionScreen.classList.remove('hide');
	}
};

showScreen('seasonScreen');
















