// QUESTIONS PER SEASON
// ------------------------------------------


// SEASON 6 ------------

var s6q1 = {
	question: "One Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};
var s6q2 = {
	question: "Two Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};
var s6q3 = {
	question: "Three Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};

var questions6 = [ null, s6q1, s6q2, s6q3 ];

// SEASON 7 ------------

var s7q1 = {
	question: "One Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};
var s7q2 = {
	question: "Two Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};
var s7q3 = {
	question: "Three Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: ["Bob The Drag Queen", "Chi Chi Devayne", "Acid Betty", "Derek Berry"],
	answer: "Derek Berry"
};

var questions7 = [ null, s7q1, s7q2, s7q3 ];

// SEASON 8 ------------

var s8q1 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Bob The Drag Queen", "image":"img/season8/bob_the_drag_queen.jpg"}, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Acid Betty", "image":"img/season8/acid_betty.jpg"},{"choice":"Derrick Berry", "image":"img/season8/derrick_berry.jpg"}],
	answer: 3

};
var s8q2 = {
	question: "Who was voted Miss Congeniality?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: 2
};
var s8q3 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q4 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q5 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q6 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q7 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q8 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q9 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};
var s8q10 = {
	question: "Who was the 100th queen to walk into the workroom?",
	video: "",
	choices: [{"choice":"Thorgy Thor", "image":"img/season8/thorgy_thor.jpg"}, {"choice":"Cynthia Lee Fontain", "image":"img/season8/cynthia_lee.jpg"},, {"choice": "Chi Chi Devayne", "image":"img/season8/chi_chi.jpg"}, {"choice":"Dax Exclamationpoint", "image":"img/season8/dax.jpg"}],
	answer: "Derek Berry"
	
};


var questions8 = [ null, s8q1, s8q2, s8q3, s8q4, s8q5, s8q6, s8q7, s8q8, s8q9, s8q10 ];





// SEASONS + CAST IMAGE
// ------------------------------------------

var seasonAllstars = {
	"name": "All Stars"
};

var season6 = {
	"name": "Season 6",
	"song": "assets/songs/season6.mp3",
	"questions": questions6
};

var season7 = {
	"name": "Season 7",
	"song": "assets/songs/season7.mp3",
	"questions": questions7
};

var season8 = {
	"name": "Season 8",
	"song": "assets/songs/season8.mp3",
	"questions": questions8
};


var seasons = [ seasonAllstars, null, null, null, null, null, season6, season7, season8 ];


// SEASON SONG - PLAY DURING GAME
// ------------------------------------------


// SOUNDS FOR RIGHT AND WRONG ANSWERS
// -----------------------------------------


// POP-UP TEXT FOR RIGHT AND WRONG ANSWERS
// -----------------------------------------



console.log("data works");
